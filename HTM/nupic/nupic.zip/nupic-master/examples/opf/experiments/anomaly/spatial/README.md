## These Examples are Out-Of-Date

The model parameters within the `description.py` files of the examples within this directory are out of date, and will not produce proper anomaly scores.