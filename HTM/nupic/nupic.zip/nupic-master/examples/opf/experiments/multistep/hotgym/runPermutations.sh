#!/bin/bash

python ../../bin/NupicRunPermutations.py hotgym/permutations.py  --searchMethod=v2 --maxWorkers=4


