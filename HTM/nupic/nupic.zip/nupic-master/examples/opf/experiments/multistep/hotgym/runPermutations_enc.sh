#!/bin/bash

python ../../bin/NupicRunPermutations.py hotgym/permutations_enc.py  --searchMethod=v2 --maxWorkers=5


