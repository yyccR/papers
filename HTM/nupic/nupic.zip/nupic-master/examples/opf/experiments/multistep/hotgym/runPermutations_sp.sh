#!/bin/bash

python ../../bin/NupicRunPermutations.py hotgym/permutations_sp.py  --searchMethod=v2 --maxWorkers=4


