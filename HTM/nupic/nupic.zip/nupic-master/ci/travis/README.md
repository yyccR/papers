## Travis-CI Scripts

The bash scripts in this directory are run only in Travis-CI, and are placed here to help simplify the [`.travis.yml`](../../.travis.yml) configuration file. This is mostly because we build in Linux and OS X, so each needs to run different scripts in order to install NuPIC.

These scripts are not meant to be run locally by users or developers of NuPIC.