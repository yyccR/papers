# Changelog

## 0.4.16

* SpatialPooler: Stop rounding the boost factors
* SpatialPooler: Rename "maxBoost" to "boostingStrength"
* SpatialPooler: Remove minActiveDutyCycles and minPctActiveDutyCycles from spatial pooler

## 0.4.15

* SpatialPooler: Tweak the boost factor rounding to mimic numpy's rounding of float32s

## 0.4.14

* SpatialPooler: New boosting algorithm
* SpatialPooler: Stop putting tie-break info into the overlaps. `getBoostedOverlaps()` return values are now more correct.
* SpatialPooler: Use an EPSILON when comparing permanences to a threshold to avoid floating point differences.
* SpatialPooler: Round the boost factors to two decimal places to avoid floating point differences.

## 0.4.13

* Use VERSION file when generating docs.
* 64-bit gcc on Windows build error
* New: setZerosOnOuter, increaseRowNonZeroCountsOnOuterTo
* Remove a nupic.math test that should stay in nupic
* Use unittest, not unittest2, to match the nupic.core CI config
* Add C++ unit tests for the new SparseMatrix methods
* Finish moving nupic.bindings math tests to nupic.core
* s/AboveAndBelow/BelowAndAbove
* Moves some tests for SWIG bindings from nupic to nupic.core
* Better method names: s/AboveAndBelow/BelowAndAbove
* Four new SparseMatrix methods, enabling batch synapse learning
* Expose the nrows,ncols SparseBinaryMatrix ctor in the bindings

## 0.4.12

* Updated to numpy 1.11.2 everywhere.
* Initialize timer variable in 'Regioncpp' file

## 0.4.11

* Botched release, unavailable.

## 0.4.10

* Removes version as part of iterative artifact name
* Deleted linux ci scripts for travis.
* Removed calls to linux ci scripts, forced platform=darwin
* Remove gcc builds from matrix.
* Using image w/ same version of xcode as last passing master build
* Remove some executables from test list that we don't want to run every build.
* Complete test coverage for region registration.
* Reduce build times by removing some executables from build.
* Update py_region_test for new behavior and make sure the test is run in CI.
* Fixes #1108 by only throwing exception when registering region with class name that is already registered if the new region is from a different module than the original.
* Remove unused vagrant configuration
* Remove default values for vectors because GCC can't handle it
* gcc error: checking whether a UInt is positive
* "depolarizeCells", "reinforceCandidates", "growthCandidates"

## 0.4.9

* Obey wrapAround paramater for columns, not just inputs
* Make sure exceptions are properly exposed when parsing dataType in region spec.
* Network API: allow Bools to be used as creation params
* DEVOPS-157 Remove now-unused RESULT_KEY env var from the build-and-test-nupic-bindings.sh interface.
* Handle new synapsesForSegment behavior in Connections perf test

## 0.4.8

* Add missing argument to `Set-PsDebug -Trace`
* Issue1075 fix py_region_test failure on windows (#1082)
* Perf: Walk neighborhoods via iterators.

## 0.4.7

* Check that TM input is sorted indices in Release builds
* Update inhibition comments and docstrings.
* Use C arrays in TemporalMemory. Allows numpy array reuse.
* Added that `-DNUPIC_BUILD_PYEXT_MODULES=ON` is the default at this time.
* Added information about usage of the NUPIC_BUILD_PYEXT_MODULES cmake property.
* Describe flatIdx in Connections docstring
* Consistent param ordering between implementations.
* Store "numActivePotentialSynapses". No more "SegmentOverlap".

## 0.4.6

* Templates: Stop inferring const unnecessarily
* Build error sometimes in clang -- need copy constructor
* Check that minThreshold <= activationThreshold
* Split compute into activateCells and activateDendrites
* TM and ETM cleanup
* ETM: Grow synapses on active segments, not just matching segments
* Removal of MSVC TP compilation flag
* Also do the learnOnOneCell serializaton check in ::save
* Implement learnOnOneCell in the ETM

## 0.4.5

* Removed no longer used pre-built Swig executables for various flavors of Linux; nupic.core automatically builds Swig from embedded sources on non-Windows platforms.
* DEVOPS-141 Apply an export map to OS X, Linux, and MINGW builds of nupic.bindings shared objects.
* Refactor extension build steps into a function shared by algorithms, math, engine_internal, etc. in preparation for adding export maps.
* Work around issue in cmake 2.8.7: have external project AprUtil1StaticLib depend directly on external project Apr1StaticLib instead of its library wrapper ${APR1_STATIC_LIB_TARGET}; the latter was incorrectly interperting the dependency as another external project instead of library; but worked correctly on cmake 2.8.12.
* Completed wrapping of external static libs in `add_library` targets
* Represent external build of capnproto as single static library with target name ${CAPNP_STATIC_LIB_TARGET} and containing all capnproto library objects.
* No need for custom target in CREATE_CAPNPC_COMMAND function, since nupic_core_solo is the only consumer of the custom command's outputs.
* Try building nupic_core_solo intermediate static library without specifying system libraries. It's a static library and shouldn't need additional linking information.
* Removed nupic_core_solo from installed targets, since it's only an intermediate artifact and not intended to be an output product.
* issue-1034 Reorganized build to link nupic_core static library tests against the "combined" nupic_core static library, which is considered an output artifact, instead of nupic_core_solo static lib, which is only an intermediate step.
* Use library utils to correctly combine multiple static libraries into a single one.
* DEVOPS-135 Implement a hacky work-around by preloading pycapnp's exteions DLL in RTLD_GLOBAL mode, which enables resultion of capnproto references when nupic.bidnings extensions are loaded.
* Consider EPSILON while finding minPermanenceSynapse
* Refactor to make GCC stop finding false positives
* New implementation of GCC_UNINITIALIZED_VAR
* DEVOPS-135 Remove capnproto from python extensions shared libs in order to avoid conflict with capnproto methods compiled into pycapnp, possibly compiled with a different compiler/version and with different compiler/linker flags. Instead, we rely on dynamic linking of the necessary symbols from capnproto in pycapnp.
* Avoid clang error "unknown warning option '-Wno-maybe-uninitialized'"
* Store EPSILON as a static const Permanence
* Disable GCC's maybe-uninitialized warnings. Too many false positives.
* Fixes nupic.core github issue #1031: rename EXTERNAL_STATICLIB_CONFIGURE_DEFINITIONS_OPTIMIZED_STR to EXTERNAL_STATICLIB_CONFIGURE_DEFINITIONS_OPTIMIZED and turn it into a list.
* fixes floating point comparison bug
* Use group_by in TemporalMemory. No more ExcitedColumns.
* Work around another GCC maybe-uninitialized faulty error
* Build error when including <GroupBy.hpp> without <algorithm>
* a fresh look at ExcitedColumns: it's just a group_by
* Fixed indexing bug in serialization
* Fix the unsigned int underflow bug in the ETM
* Workaround for a mingwpy issue
* DEVOPS_116 Add stock Numenta file headers and improve some comments in manylinux wheel build scripts.
* Fixed version bug in SDR classifier deserialization
* Updated bindings to handle SDR classifier
* Fix bug in TemporalMemory save / load
* Make getLeastUsedCell non-allocating
* Put ExcitedColumns in a namespace to avoid collisions
* Add apical dendrites to ExtendedTemporalMemory
* DEVOPS-116 Implement prototype manylinux wheel build using docker image numenta/manylinux1_x86_64:centos6.8
* Stop implying pycapnp is in requirements.txt
* Updated SDRClassifier to match header file on getters/setters
* Fixed memory error (off-by-one in weight matrix creation)
* Fixed include bug in SDRClassifier
* Stable implementation of save/load for SDRClassifier
* Ignore installed version of pip.
* Make sure pip gets installed and that we get console output for everything.
* DEVOPS-84 Add support for building nupic.bindings for OS X in bamboo
* change heap allocation to stack allocation of Network
* Merged upstream changes and backed out the disabling of link time optimizations since it now appears to work on the ARM.
* Add a "formInternalConnections" parameter
* Add new "experimental" SWIG module
* Move ETM to "experimental" namespace
* Support "external active cells" in the ETM
* Use std::move to keep the previous active cells
* Untangle the pieces that calculate segment excitation
* Get rid of the Cell struct
* Initial version of ExtendedTemporalMemory: copy-pasted TM
* added blurps for CMAKE_AR and CMAKE_RANLIB
* CMakeLists.txt cleaned up, vars renamed, docs updated
* Updates pycapnp to 0.5.8.
* network-factory adds missing newline to test file
* network-factory updates test to ensure created network is unregistered.
* deprecate-spec-vars moves documentation from Spec to PyRegion
* network-factory adds a test to show that creating a network without any regions or links works
* network-factory expose functions to bindings and extend functionality to accept a yaml string
* network-factory cleans up includes and makes createNetworkFromYaml public
* updated conditional cmake_args, fixes #981
* network-factory passes yaml parser instead of path
* network-factory ensure Network destructor is called on error
* deprecate-spec-vars set defaults for regionLevel and requireSplitterMap and make them optional
* Removed the duplicate conditional addition of the NTA_ASM compiler flag from src/CMakeLists.txt.  The original remains in CommonCompilerConfig.
* Removed check for Wreturn-type compatibility
* CMake warning if total memory is less than 1GB
* Added back the -O2 flag and the -Wno-return-type flag
* GCC Bitness handling
* Remove NTA_ASM flag
* Removed the inversion of the NTA_ASM logic made by @codedhard
* 1. Added CMake flag to make arm specific changes to the build 2. Used new CMake flag to disable inline assembly in build 3. Added NTA_ASM conditional to parts of ArrayAlgo.hpp that didn't use it    to enable inline assembly
* Add visualization event handlers to Connections class

## 0.4.4

* Timer: test drift
* add CSV parser library

## 0.4.3

* Adds include-what-you-use option in CMake configuration.
* Use the supported mingwpy toolchain from pypi.anaconda.org/carlkl/simple
* Define BOOST_MATH_NO_LONG_DOUBLE_MATH_FUNCTIONS for nupic.core source build in attempt to make build work with official mingwpy toolchain
* Protect all public member variables (except connections)
* Move algorithm details out of the compute method
* Split bamboo linux build into debug and release.
* Move common environment setup for Bamboo into separate script.
* Update SWIG to use local tarfile rather than download from sourceforge.
* Store the new lastUsedIteration, don't just increment old one
* Unit test: destroyed synapse + segment reuse
* Bugfix: Keep the destroyed synapses count in sync.
* Walk the columns and segments via ExcitedColumns iterator
* Fail loudly when Python regions reassign an output
* Disable asserts in release builds
* De-duplicate a loop.
* Removes 'long double', NTA_QUAD_PRECISION, and Real128 references from our code.
* Add Proto for SDR Classifier
* TemporalMemory: replace phases with "columnSegmentWalk". Much faster.
* MovingAverage.compute() returns updated value

## 0.4.2

* Define and use environment variables containing compiler and linker flags specifically for 3rd-party source code.
* Revert to installing mingwpy toolchains from https://bitbucket.org/carlkl/mingw-w64-for-python/downloads.
* Better rand() approach, won't ever be greater than 1
* Stop computing overlaps twice per timestep. 4% faster.
* Stop storing segment overlap counts in a map. Now 56% faster.
* Enable errors for windows32 build in the matrix.
* Use proper float comparisons to avoid issues on 32 vs 64 bit machines.
* Perf: When using sets, use std::set::find, not std::find
* Swig needs `-include cmath` when building with mingw toolchain.
* Initialize swig_generated_file_compile_flags directly from COMMON_CXX_FLAGS_OPTIMIZED to avoid -Werror.
* Comment out header and binary install targets in CapnProto.cmake, since this is a duplicate of the exact same steps in srce/CMakeLists.txt, which installs other externals as well.
* Attempt to fix execution of helloregion test from Travis build by modifying .travis.yml to change directory to build/release/bin just as instructed by nupic.core/README.md.
* Added a comment about nupic.core's swig wraps relying on the macro CAPNP_LITE to have a value.
* Fix windows build of nupic.core's Swig wraps that expects CAPNP_LITE not only to be defined (capnp recommends just defining it), but to actually have a value (non-zero).
* Invoke additional nupic.core tests in Travis to make sure that things get tested and tests don't get broken again unnoticed:   connections_performance_test   helloregion   hello_sp_tp   prototest
* Refactored CommonCompilerConfig.cmake to exposed optimized and unoptimized flag sets. Fixed linux GCC build of CapnProto components by changing its configuration to use unoptimized versions of common flags. Cleaned up use of local variables in src/CMakeFiles.txt. nupic.core/CmakeLists.txt is now the only place that defines REPOSITORY_DIR for use by other modules. Fixed dependency in add_custom_command function inside CREATE_CAPNPC_COMMAND to use passed-in arg SPEC_FILES instead of a property from src/CMakeLists.txt.
* Add BITNESS to Swig.cmake

## 0.4.1

* Cast arg to UInt32 to avoid call resolution ambiguity on the value.write() method on Win32 platform.
* Finish adding support for the Bool type
* Expose encoder's 'n' so other regions' inputWidth is calculable from the outside
* Remove reference to deleted Linear.cpp.
* Run nupic.core encoders via boilerplate Sensor wrapper
* Removes Linear.hpp, Linear.cpp, and reference in algorithms.i since it doesn't appear to be used anywhere.
* Support Debug builds in Clang, put them in README
* Add a NTA_BasicType_Bool so that we can parse bools in YAML
* FloatEncoder base, no more common Encoder, new signature
* Prepends BINDINGS_VERSION plus dot separater to wheel filename
* Fix integer division bug, add tests that would catch this bug
* Don't divide by a constant. Multiply. Dodges divide-by-0.
* Explicitly mark all derived virtual methods as virtual.
* Fix gcc build issue
* C++ Encoder base + ScalarEncoder + ported unit tests

## 0.4.0

* Reduce EPSILON threshold for TM to minitage compatibility issues.
* Updates AV yaml to push a commit-sha'd wheel to AWS
* Reduce permanence threshold by epsilon before comparing to avoid rounding edge cases
* Make threshold for destroying synapses larger to catch roundoff errors
* Make comparison identical to python
* Add accessors for TM columnForCell and cellsForColumn
* Temporal Memory: recordIteration should be false in second call to computeActivity
* Fix: Incompatibility in Connections.computeActivity with python
* Change TM init parameters to accept segment and synapse limit.

## 0.3.1

* Secondary sort on segment idx
* Sort segments before iterating for python compatibility
* Sort unpredictedActiveColumns before iterating for python compatibility

## 0.3.0

* Updated SWIG bindings for accessors
* Added TemporalMemory accessors
* Update bindings for C++ Connections to expose 'read' class method
* Destroy lowest permanence synapse when synapse limit is reached
* Fix for bug in Segment::freeNSynapses
* Added initialization code from Tester::init into PathTest::PathTest that is required for PathTest::copyInTemp to run successfully.
* Remove references to Tester from UnitTestMain.cpp
* Deleted Tester class and TesterTest files
* Update SWIG binding of Network to add read class method
* Refactor PyRegion subclasses to take specific proto object in read
* Update SWIG binding of TemporalPooler to add read class method
* Enable basic building with ninja (cmake -GNinja)
* Added include of Log.hpp in NodeSet.hpp
* Update SWIG bindings of SpatialPooler and CLAClassifier to add read class methods to C++ classes

## 0.2.7

* Full filename for twine.
* Absolute path for twine's binary file upload.

## 0.2.6

* Fixed incorrect binary path for twine.

## 0.2.5

* Fixing twine upload of windows binary.

## 0.2.4

* Working out issues with the release process.

## 0.2.3

* Windows Support!
* Add bindings for CLAClassifier serialization
* Adding Windows twine pip install and PyPi upload
* Storing release version in VERSION in proj root.
* Makes build-from-source the default behavior for capnp and swig, requiring the flags FIND_CAPNP or FIND_SWIG to be specified in order to use a preinstalled version.
* Add Dockerfile for building nupic.core from source
* Update of Windows bindings setup
* Add "python setup.py test" option (fixes #697)
* Adding a CMake ExternalProject to download capnp win32 compiler tools
* Simplify setup.py, remove unused command line args, add setup.py clean command. Update Travis to build Python extensions as part of cmake so Python install doesn't rebuild them.
* Allow finding pre-built capnp.
* Revert back to numpy==1.9.2

## 0.2.2

* First changelog entry.
