maxPreviousSteps = 5
maxPreviousStepsWithInference = 100
maxFutureSteps = 5
