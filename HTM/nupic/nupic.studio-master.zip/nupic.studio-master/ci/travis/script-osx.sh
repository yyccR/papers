#!/bin/bash

echo
echo Running script-osx.sh...
echo

# Run NuPIC Studio
nupic_studio
